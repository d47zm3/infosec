//format string example
// by Dr. Phil Polstra @ppolstra
#include <stdio.h>

void main(int argc, char** argv)
{
	// printf accepts multiple arguments
	// first argument is a format string
	// many programmers assume this is only argument
	printf(argv[1]);
}
